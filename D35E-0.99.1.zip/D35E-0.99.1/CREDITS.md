## Disclaimer

None of the people on this list necessarily endorse me. See the respective licences for more info.

## Lorc ([CC BY 3.0](https://creativecommons.org/licenses/by/3.0/))

- [Heart Inside](https://game-icons.net/1x1/lorc/heart-inside.html)
- [Punch Blast](https://game-icons.net/1x1/lorc/punch-blast.html)
- [Brain](https://game-icons.net/1x1/lorc/brain.html)
- [Divert](https://game-icons.net/1x1/lorc/divert.html)
- [Magic Swirl](https://game-icons.net/1x1/lorc/magic-swirl.html)