# Changes
- [450](https://github.com/Rughalt/D35E/issues/450) - Welcome screen is no longer resizeable
- [449](https://github.com/Rughalt/D35E/issues/449) - Display for monsters that have
- Minor UI fixes
