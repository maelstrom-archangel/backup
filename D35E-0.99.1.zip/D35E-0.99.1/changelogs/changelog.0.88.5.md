### Bug Fixes and Changes
- Display buffs on Combat tracker and on Token
- Fixed Soulknife weapon
- Added few Psionic powers