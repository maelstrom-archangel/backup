### New Features
- Simple skill assignment changes (for creatures not using Class Progression system)
    - Better handling of bonus skill points for items
    - Additional information for multiclass creatures
    - Ability to diable skill synergies
- Better selections of skills in Skill Focus and spell schoold in Spell Specialization

### Fixes
- More small fixes
 