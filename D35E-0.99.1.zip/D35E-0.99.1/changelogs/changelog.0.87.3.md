### Bug Fixes
- Fixed rolls without dice so nice enabled