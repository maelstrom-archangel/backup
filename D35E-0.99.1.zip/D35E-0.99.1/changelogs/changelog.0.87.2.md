### Features
- Added simple Statblock NPC char sheet. It currently displays basic statistics that are needed in combat and allows updating health and rolling attacks, special abilities and saves
- Added ability to unlink Token size from Actor size, so they can be set independently
- Added ability to list Class Features in lists by type (Client setting, default off)
- Added integration with Dice So Nice! for Attack rolls.

### Bug Fixes
- Fixed permission error for Minion distance calculation
- Fixed wrong color in selects when using Custom Theme