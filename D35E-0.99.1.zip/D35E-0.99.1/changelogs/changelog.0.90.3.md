### All changes
- UI Fix
- Demo mode edits

