### Features
- Added and assigned over 100 icons to Spells from SRD

### Bug Fixes
- Fixed message about Constitution Drain not existing in roll data
- Fixes attack effect rolls not appearing correctly