### All changes
- [476](https://github.com/Rughalt/D35E/issues/476) - Link to D35E docs 
- [475](https://github.com/Rughalt/D35E/issues/475) - Unarmed Strike (Monk) stops working after adding Weapon Focus 
- [472](https://github.com/Rughalt/D35E/issues/472) - Resistance and Damage Reduction in Changes Tab not refering to things outside of itself such as Class 
- [469](https://github.com/Rughalt/D35E/issues/469) - racial HD bug sheet 
- [467](https://github.com/Rughalt/D35E/issues/467) - Paladin Lay On Hands is doing damage instead of healing 

