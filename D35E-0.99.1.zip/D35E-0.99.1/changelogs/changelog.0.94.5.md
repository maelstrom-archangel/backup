### All changes:
- Fixed treasure generator (thanks Slash)
- Fix for wrong barkskin icons in bestiary
- Fix for halfling and goblin sizes
- Fix for item browser