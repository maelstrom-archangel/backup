### All changes
- [747](https://github.com/Rughalt/D35E/issues/747) - Missing translations for monster advancement closed
- [745](https://github.com/Rughalt/D35E/issues/745) - Feature Request: energyDrain affect caster level closed
- [741](https://github.com/Rughalt/D35E/issues/741) - full attack chat card printed when rest of attack is private closed
