### All changes:
- Hotifx for attack not working
- Hotfix with buffs with special actions on activate