### Bug Fixes
- Fixed vision and lighting
- Fixed bears endurance