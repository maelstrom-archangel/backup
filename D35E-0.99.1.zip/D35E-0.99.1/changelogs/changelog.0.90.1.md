### All changes
- Fix saving fields on Saving Throw and Defense Dialogs
- Fix (@range) in Saving Throw and Defense Dialogs
- Minor UI and Translation fixes
