### New Features
- Ability to toggle wealth tab
- New item type - Valuable
- Ability to set Low-Light vision multiplier

### Fixes
- More small fixes
 