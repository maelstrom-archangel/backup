### Features
- Enhancement system can store information about the CL and Spellcasting Ability so staffs can work correctly

### All changes
- [771](https://github.com/Rughalt/D35E/issues/771) - Aura bug closed
- [769](https://github.com/Rughalt/D35E/issues/769) - Base spell compendium scorching ray formula wrong closed
- [768](https://github.com/Rughalt/D35E/issues/768) - Bug: Missing non active class features on the class description closed
- [760](https://github.com/Rughalt/D35E/issues/760) - DC value of spells in staffs closed
- [759](https://github.com/Rughalt/D35E/issues/759) - Magic Missile + Mirror Image closed
- [713](https://github.com/Rughalt/D35E/issues/713) - Divine Power Buff closed
- [697](https://github.com/Rughalt/D35E/issues/697) - Aura (Enhencement) closed
- [522](https://github.com/Rughalt/D35E/issues/522) - @attributes.bab.value is not recognize in buffs closed 

