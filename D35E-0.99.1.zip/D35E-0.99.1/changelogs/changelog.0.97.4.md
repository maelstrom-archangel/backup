### Fixes
- Hotfix for attack rolls chat messages

### All changes
- [787](https://github.com/Rughalt/D35E/issues/787) - Feature Request: Using formula in the Maximized field of the system Health Configuration. closed 
- [720](https://github.com/Rughalt/D35E/issues/720) - Feature Request - Being able to test in conditions (special actions) the combat status closed 