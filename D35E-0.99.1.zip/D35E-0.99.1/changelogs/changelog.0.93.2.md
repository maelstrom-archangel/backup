### New features:
- Ability to force automatical number of attack scaling from BAB per attack

### All changes:
- [568](https://github.com/Rughalt/D35E/issues/568) - Show in QuickBar for Class Features/Feats creates multiple buttons. closed 
- [567](https://github.com/Rughalt/D35E/issues/567) - Weapon Name does not set properly on Weapon Focus/Specialization closed 
- [566](https://github.com/Rughalt/D35E/issues/566) - Encumbrance Calculations Broken closed 
- [565](https://github.com/Rughalt/D35E/issues/565) - Low-light vision doesn't work propertly closed 
- [562](https://github.com/Rughalt/D35E/issues/562) - Feature request: Move "automatic scale number of attacks" closed 
- [523](https://github.com/Rughalt/D35E/issues/523) - FR-Formulas in Item Value stat closed