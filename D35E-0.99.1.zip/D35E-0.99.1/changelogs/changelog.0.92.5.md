### All changes
- Limited amount of calls system does to Companion
- Added feedback for manual Companion sync
- Fixed web addresses in tokens used for shapechange causing errors
- Fixed PV/libWrapper error
- [491](https://github.com/Rughalt/D35E/issues/491) - Bonus attacks from Rapid Shot and Haste are added at the top of the list.
