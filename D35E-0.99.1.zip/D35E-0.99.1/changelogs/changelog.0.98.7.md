### Fixes
- Fixed a lot of UI issues related to v9
- Fixed Initiative tracker
- Fixed Celestial and Fiendish templates creature type, allow templates not to change the type of creature
- Fixed vision issues
 