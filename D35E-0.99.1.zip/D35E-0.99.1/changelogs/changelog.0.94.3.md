### All changes:
- Hotifx for adding spells/scrolls via drag and drop