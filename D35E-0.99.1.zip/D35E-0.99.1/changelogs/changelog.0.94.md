### New Features
- Spell Cards system
    - New item type - Card - that is similar to spell
    - New character sheet tab - Spell Cards - that allows managing Cards in a deck like enviroment ()

### All changes:
- [601](https://github.com/Rughalt/D35E/issues/601) - [feature request] Make radio button more visible closed 
- [600](https://github.com/Rughalt/D35E/issues/600) - Multi-class Rogue gets no Sneak Attack Bonus closed 
- [598](https://github.com/Rughalt/D35E/issues/598) - SRD says Medium Armour max for barbarian but Heavy Armour Proficiency assigned at 1st level closed 
- [595](https://github.com/Rughalt/D35E/issues/595) - Formula error in item {0} on characters with more than one class closed 
- [592](https://github.com/Rughalt/D35E/issues/592) - Bard has 3 spells per day at first level but should have 2 closed 
- [591](https://github.com/Rughalt/D35E/issues/591) - Leveling up after level 1 still gives x4 skill points per level to spend closed 
- [581](https://github.com/Rughalt/D35E/issues/581) - Change the cost of the points in the "Point Buy" screen. closed