### Bug Fixes and Changes
- Hotfix for wildshape buff