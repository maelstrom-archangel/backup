### Bug Fixes
- Wrong compendium links in sidebar
- Fixed bug with opening Level Up Data window when no Bonus Skill Points counter existed