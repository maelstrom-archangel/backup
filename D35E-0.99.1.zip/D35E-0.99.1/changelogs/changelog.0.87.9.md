### Features
- Add Healing damage type that always applies healing

### Bug Fixes
- Make spell use slot *after* casting them
- Fix Ray measure template