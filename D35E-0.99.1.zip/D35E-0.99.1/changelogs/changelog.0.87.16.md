### Bug Fixes
- [#220](https://github.com/Rughalt/D35E/issues/220) - Carrying capacity calculation and Str enhancement
- [#218](https://github.com/Rughalt/D35E/issues/218) - Items in Container and Inventory Value
- [#224](https://github.com/Rughalt/D35E/issues/224) - Formula for Inspire Courage produce wrong progression
- [#225](https://github.com/Rughalt/D35E/issues/225) - Saving Throws
