### New Features
- Ability to set up type of feat (Supernatural/Extraordinary/Other)

### All changes:
- [606](https://github.com/Rughalt/D35E/issues/606) - clicks on Weapons Properties buttons register on oldest open weapon window closed 
- [605](https://github.com/Rughalt/D35E/issues/605) - Items missing names closed 
- [604](https://github.com/Rughalt/D35E/issues/604) - Feature request: Being able to add type of class feature (sortilegic, supernatural or extraordinary) closed 
- [603](https://github.com/Rughalt/D35E/issues/603) - Fast healing chat card is not applying healing to the character closed 
- [602](https://github.com/Rughalt/D35E/issues/602) - Gobelin race doesn't apply small size closed 