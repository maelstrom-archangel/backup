### Bug Fixes
- [#213](https://github.com/Rughalt/D35E/issues/213) - Saving throws not including bonuses
- [#212](https://github.com/Rughalt/D35E/issues/212) - Game Master Tools Icon is visible to Players
- Fixed actors with containers misbehaving