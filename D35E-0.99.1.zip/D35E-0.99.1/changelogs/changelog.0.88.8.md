### Bug Fixes and Changes
- Hotfix for special actions