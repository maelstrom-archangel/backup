### Bug Fixes and Changes
- Hotfix for level up