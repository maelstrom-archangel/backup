### SRD
- Added Point-Blank Shot, Greater Weapon Specialization and Greater Weapon Focus feats

### Bug Fixes
- Fix minor bugs related to Combat Changes
- [#107](https://github.com/Rughalt/D35E/issues/107) - Rapid shot doesn't apply -2 penalty to all attacks
- [#108](https://github.com/Rughalt/D35E/issues/108) - Spellbook jumps back to the top every time anything changes
