### All changes
- Fixed Spell Focus feats not working
- Minor changes regarding Companion configuration
- Demo mode

