### Bug Fixes
- 0 Level spell no longer do not consume any uses
- More fixes for time tracking in buffs
- Wildshape and Dazzled condition modifiers removed from changes, ignored on all items