### Features
- Reworked Class and Racial Abilities
    - You can now add Ability from all scanned compendia directly on Race or Class Item details
    - You can disable default Abilities to add Alternative Class Features
    
### Bug Fixes
- Fixed inifinte loop when updating Tokens with containers
- [#138](https://github.com/Rughalt/D35E/issues/138) - Fixed buff tracking for linked actors
- [#135](https://github.com/Rughalt/D35E/issues/135) - Fixed spell with no material component toggle selected displaying message.