- [705](https://github.com/Rughalt/D35E/issues/705) - Cannot delete weight on item or set back to "0" closed
- [704](https://github.com/Rughalt/D35E/issues/704) - Low-light Vision radio-button on custom Races closed
- [696](https://github.com/Rughalt/D35E/issues/696) - Deleting an Aura on a character don't remove the bonus automatically on other player closed
- [676](https://github.com/Rughalt/D35E/issues/676) - Paladin total caster level should be half its class level closed 

