### SRD
- Rogue abilities are now displayed correctly

### Features
- Added special functions so [LMRTFY](https://foundryvtt.com/packages/lmrtfy/) can work.

### Bug Fixes
- Fixed vision
- Fixed Spontaneous caster spell slots