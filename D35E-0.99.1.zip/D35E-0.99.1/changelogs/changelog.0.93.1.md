### New features:
- Added chat messages for Ability Damage and Ability Drain

### Fixes
- Fixed senses set up window
- Multiple fixes to 0.8.x compatibility

### All changes:
- [558](https://github.com/Rughalt/D35E/issues/558) - clicking Submit on Senses dialog does not dismiss dialog closed 
- [554](https://github.com/Rughalt/D35E/issues/554) - Carried Weight does not calculate correctly closed 
- [552](https://github.com/Rughalt/D35E/issues/552) - D3E Treasure Generator not working in 0.8.6/0.93 closed 
- [550](https://github.com/Rughalt/D35E/issues/550) - Names of the playlists with custom skin are showed up cutted. closed 
- [549](https://github.com/Rughalt/D35E/issues/549) - Bug: Class features requisites not passing formula closed 
- [542](https://github.com/Rughalt/D35E/issues/542) - FR: Display outcome of special actions in chat closed 